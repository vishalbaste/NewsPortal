<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>The Vishal News Blog</title>
    <meta name="description" content="Hello i Am Vishal Baste"/>
    <meta name="keywords" content="Vishal Baste,Vishal"/>
    <meta name=”geo.placename” content=”Global” />
    <meta name="distribution" content="Global" />
    <meta name=copyright content="www.vishalbaste.com" />
    <meta name="author" content="Vishal Baste">
<!-- Header Part -->
<?php include 'header.php' ?>



<div class="container">
    <div class="flex">
<div class="flex-1">
<?php include 'blogs.php' ?>
</div>
<div class="flex-2">
<?php include 'sitebar.php' ?>
</div>
</div>
</div>












<div class="" id="text1">Helo</div>







<!-- Footer File -->
<?php include 'footer.php' ?>
















<!-- All Cotri API   https://coronavirus-19-api.herokuapp.com/countries -->
